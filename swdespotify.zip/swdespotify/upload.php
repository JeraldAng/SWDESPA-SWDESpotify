<?php
    error_reporting(E_ALL);

	$file = explode('.', $_FILES['file']['name']);
	$ext = $file[count($file) - 1];
	$name = substr($_FILES['file']['name'], 0, (strlen($ext) + 1) * -1);
	$location = './songs/';
	$cntr = 1;
	$tmp_name = $name;
	
	while(file_exists($location.$tmp_name.'.'.$ext)){
		$tmp_name = $name.'('.$cntr.')';
		$cntr += 1;
	}
	
	if(move_uploaded_file($_FILES['file']['tmp_name'], $location.$tmp_name.'.'.$ext)){
		echo $tmp_name.'.'.$ext;
	}else{
		echo "failed";
	}
	
	
?>